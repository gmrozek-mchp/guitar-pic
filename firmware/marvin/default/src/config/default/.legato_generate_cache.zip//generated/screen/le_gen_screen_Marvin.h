#ifndef LE_GEN_SCREEN_MARVIN_H
#define LE_GEN_SCREEN_MARVIN_H

#include "gfx/legato/legato.h"

#include "gfx/legato/generated/le_gen_scheme.h"
#include "gfx/legato/generated/le_gen_assets.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

// screen member widget declarations
extern leWidget* Marvin_PANEL_BASE;
extern leWidget* Marvin_PANEL_BASE_TOP;
extern leWidget* Marvin_PANEL_BASE_DIVIDER;
extern leWidget* Marvin_PANEL_BASE_BOTTOM;
extern leWidget* Marvin_PANEL_SYSTEM_LEFT;
extern leWidget* Marvin_PANEL_SYSTEM_RIGHT;
extern leButtonWidget* Marvin_BUTTON_SYSYEM_NAVIGATION;
extern leWidget* Marvin_PANEL_SYSTEM_TITLE;
extern leLabelWidget* Marvin_LABEL_GUITAR_PIC;
extern leLabelWidget* Marvin_LABEL_MARVIN;
extern leButtonWidget* Marvin_BUTTON_SYSTEM_ACTIVE;
extern leImageScaleWidget* Marvin_IMAGE_MICROCHIP;
extern leWidget* Marvin_PANEL_BASE_LEFT;
extern leWidget* Marvin_PANEL_BASE_CENTER;
extern leWidget* Marvin_PANEL_BASE_RIGHT;
extern leWidget* Marvin_PANEL_ROBOT_CONTROLS;
extern leWidget* Marvin_PANEL_PERFORMANCE;
extern leLabelWidget* Marvin_LABEL_ROBOT_CONTROL;
extern leWidget* Marvin_panel_Container_7;
extern leWidget* Marvin_panel_Button__margin_;
extern leWidget* Marvin_panel_Contas;
extern leWidget* Marvin_panel_Button;
extern leWidget* Marvin_panel_Button_0;
extern leWidget* Marvin_panel_Icon_0;
extern leLabelWidget* Marvin_label_START;
extern leImageWidget* Marvin_image_Icon_0;
extern leWidget* Marvin_panel_Icon_1;
extern leLabelWidget* Marvin_label_CALIBRATE;
extern leImageWidget* Marvin_image_Icon_1;
extern leWidget* Marvin_panel_Button_1;
extern leWidget* Marvin_panel_Icon_2;
extern leLabelWidget* Marvin_label_EMERGENCY_STOP;
extern leImageWidget* Marvin_image_Icon_2;
extern leWidget* Marvin_panel_Container_8;
extern leWidget* Marvin_panel_Container_9;
extern leWidget* Marvin_panel_Container_10;
extern leWidget* Marvin_panel_Container_11;
extern leWidget* Marvin_panel_Text;
extern leWidget* Marvin_panel_Text_0;
extern leLabelWidget* Marvin_label_Calibration;
extern leLabelWidget* Marvin_label_READY;
extern leWidget* Marvin_panel_Text_1;
extern leWidget* Marvin_panel_Text_2;
extern leLabelWidget* Marvin_label_Motor_Status;
extern leLabelWidget* Marvin_label_OPERATIONAL;
extern leWidget* Marvin_panel_Text_3;
extern leWidget* Marvin_panel_Text_4;
extern leLabelWidget* Marvin_label_Servo_Power;
extern leLabelWidget* Marvin_label__12_4V;
extern leLabelWidget* Marvin_LABEL_PERFORMANCE;
extern leWidget* Marvin_panel_Container_12;
extern leWidget* Marvin_panel_Container_13;
extern leWidget* Marvin_panel_Container__margin__0;
extern leWidget* Marvin_panel_Container__margin__3;
extern leWidget* Marvin_panel_Container__margin__5;
extern leWidget* Marvin_panel_Container_14;
extern leWidget* Marvin_panel_Container_15;
extern leWidget* Marvin_panel_Icon_3;
extern leWidget* Marvin_panel_Text_5;
extern leImageWidget* Marvin_image_Icon_3;
extern leLabelWidget* Marvin_label_SCORE;
extern leLabelWidget* Marvin_label__135_416;
extern leWidget* Marvin_panel_Container_16;
extern leWidget* Marvin_panel_Container_17;
extern leWidget* Marvin_panel_Container__margin__1;
extern leWidget* Marvin_panel_Container__margin__2;
extern leWidget* Marvin_panel_Icon_4;
extern leWidget* Marvin_panel_Text_6;
extern leImageWidget* Marvin_image_Icon_4;
extern leLabelWidget* Marvin_label_ACCURACY;
extern leWidget* Marvin_panel_Container_18;
extern leWidget* Marvin_panel_Text_7;
extern leWidget* Marvin_panel_Text_8;
extern leLabelWidget* Marvin_label__94_5_;
extern leLabelWidget* Marvin_label__1247_1320;
extern leWidget* Marvin_panel_Container_19;
extern leWidget* Marvin_panel_Container_20;
extern leWidget* Marvin_panel_Container_21;
extern leWidget* Marvin_panel_Container_22;
extern leWidget* Marvin_panel_Container__margin__4;
extern leWidget* Marvin_panel_Icon_5;
extern leWidget* Marvin_panel_Text_9;
extern leImageWidget* Marvin_image_Icon_5;
extern leLabelWidget* Marvin_label_COMBO;
extern leWidget* Marvin_panel_Container_23;
extern leWidget* Marvin_panel_Text_10;
extern leWidget* Marvin_panel_Text_11;
extern leLabelWidget* Marvin_label__142x;
extern leLabelWidget* Marvin_label_Best__89;
extern leWidget* Marvin_panel_Container_24;
extern leWidget* Marvin_panel_Container_25;
extern leWidget* Marvin_panel_Container_28;
extern leWidget* Marvin_panel_Container_26;
extern leWidget* Marvin_panel_Container_27;
extern leLabelWidget* Marvin_label_HIT;
extern leLabelWidget* Marvin_label__1247;
extern leWidget* Marvin_panel_Container_29;
extern leWidget* Marvin_panel_Container_30;
extern leLabelWidget* Marvin_label_MISS;
extern leLabelWidget* Marvin_label__73;
extern leWidget* Marvin_PANEL_VIDEO_STREAM;
extern leWidget* Marvin_PANEL_GUITAR;
extern leImageWidget* Marvin_IMAGE_STAND_BY;
extern leWidget* Marvin_PANEL_NO_SIGNAL;
extern leImageWidget* Marvin_IMAGE_LED_NO_SIGNAL;
extern leLabelWidget* Marvin_LABEL_NO_SIGNAL;
extern leWidget* Marvin_PANEL_GUITAR_ROW_0;
extern leWidget* Marvin_PANEL_GUITAR_ROW_1;
extern leWidget* Marvin_PANEL_GUITAR_ROW_2;
extern leLabelWidget* Marvin_LABEL_GUITAR_MANUAL_CONTROL;
extern leButtonWidget* Marvin_BUTTON_GUITAR_ENABLE;
extern leButtonWidget* Marvin_BUTTON_GUITAR_FRET_GREEN;
extern leButtonWidget* Marvin_BUTTON_GUITAR_FRET_RED;
extern leButtonWidget* Marvin_BUTTON_GUITAR_FRET_YELLOW;
extern leButtonWidget* Marvin_BUTTON_GUITAR_FRET_BLUE;
extern leButtonWidget* Marvin_BUTTON_GUITAR_FRET_ORANGE;
extern leButtonWidget* Marvin_BUTTON_GUITAR_STRUM_UP;
extern leButtonWidget* Marvin_BUTTON_GUITAR_MINUS;
extern leButtonWidget* Marvin_BUTTON_GUITAR_PLUS;
extern leButtonWidget* Marvin_BUTTON_GUITAR_STRUM_DOWN;
extern leWidget* Marvin_panel_SystemStatus;
extern leWidget* Marvin_panel_NoteVisualizer;
extern leWidget* Marvin_panel_ConfigPanel;
extern leWidget* Marvin_panel_Heading_3_2;
extern leWidget* Marvin_panel_Container_39;
extern leLabelWidget* Marvin_label_SYSTEM_STATUS;
extern leWidget* Marvin_panel_Container_40;
extern leWidget* Marvin_panel_Container_45;
extern leWidget* Marvin_panel_Container_50;
extern leWidget* Marvin_panel_Container__margin__9;
extern leWidget* Marvin_panel_Container_41;
extern leWidget* Marvin_panel_Container__margin__6;
extern leWidget* Marvin_panel_Container_42;
extern leWidget* Marvin_panel_Text_15;
extern leWidget* Marvin_panel_Icon_8;
extern leWidget* Marvin_panel_Text_14;
extern leImageWidget* Marvin_image_Icon_8;
extern leLabelWidget* Marvin_label_CPU;
extern leLabelWidget* Marvin_label__29_9_;
extern leWidget* Marvin_panel_Container_43;
extern leWidget* Marvin_panel_Container_44;
extern leWidget* Marvin_panel_Container_46;
extern leWidget* Marvin_panel_Container__margin__7;
extern leWidget* Marvin_panel_Container_47;
extern leWidget* Marvin_panel_Text_17;
extern leWidget* Marvin_panel_Icon_9;
extern leWidget* Marvin_panel_Text_16;
extern leImageWidget* Marvin_image_Icon_9;
extern leLabelWidget* Marvin_label_MEMORY;
extern leLabelWidget* Marvin_label__62_3_;
extern leWidget* Marvin_panel_Container_48;
extern leWidget* Marvin_panel_Container_49;
extern leWidget* Marvin_panel_Container_51;
extern leWidget* Marvin_panel_Container__margin__8;
extern leWidget* Marvin_panel_Container_52;
extern leWidget* Marvin_panel_Text_19;
extern leWidget* Marvin_panel_Icon_10;
extern leWidget* Marvin_panel_Text_18;
extern leImageWidget* Marvin_image_Icon_10;
extern leLabelWidget* Marvin_label_TEMP;
extern leLabelWidget* Marvin_label__46_3_C;
extern leWidget* Marvin_panel_Container_53;
extern leWidget* Marvin_panel_Container_54;
extern leWidget* Marvin_panel_Container_55;
extern leWidget* Marvin_panel_Container_56;
extern leWidget* Marvin_panel_Container_58;
extern leWidget* Marvin_panel_Inline_content;
extern leWidget* Marvin_panel_Container_57;
extern leLabelWidget* Marvin_label_UPTIME;
extern leLabelWidget* Marvin_label__3h_24m;
extern leWidget* Marvin_panel_Inline_content_0;
extern leWidget* Marvin_panel_Container_59;
extern leLabelWidget* Marvin_label_LATENCY;
extern leLabelWidget* Marvin_label__12ms;
extern leWidget* Marvin_panel_Heading_3_3;
extern leWidget* Marvin_panel_Container__margin__10;
extern leLabelWidget* Marvin_label_NOTE_TRACKING;
extern leWidget* Marvin_panel_Container_60;
extern leWidget* Marvin_panel_Container_96;
extern leWidget* Marvin_panel_Container_105;
extern leWidget* Marvin_panel_Container_109;
extern leWidget* Marvin_panel_Container_111;
extern leWidget* Marvin_panel_Container_132;
extern leWidget* Marvin_panel_Container_138;
extern leWidget* Marvin_panel_Container_141;
extern leWidget* Marvin_panel_Container_144;
extern leWidget* Marvin_panel_Container_149;
extern leWidget* Marvin_panel_Container_169;
extern leWidget* Marvin_panel_Container_170;
extern leWidget* Marvin_panel_Container_97;
extern leWidget* Marvin_panel_Container_98;
extern leWidget* Marvin_panel_Container_106;
extern leWidget* Marvin_panel_Container_110;
extern leWidget* Marvin_panel_Container_112;
extern leWidget* Marvin_panel_Container_133;
extern leWidget* Marvin_panel_Container_139;
extern leWidget* Marvin_panel_Container_140;
extern leWidget* Marvin_panel_Container_142;
extern leWidget* Marvin_panel_Container_143;
extern leWidget* Marvin_panel_Container_145;
extern leWidget* Marvin_panel_Container_146;
extern leWidget* Marvin_panel_Container_150;
extern leWidget* Marvin_panel_Container_151;
extern leWidget* Marvin_panel_Container_171;
extern leWidget* Marvin_panel_Container_173;
extern leWidget* Marvin_panel_Container_175;
extern leWidget* Marvin_panel_Container_177;
extern leWidget* Marvin_panel_Container_179;
extern leWidget* Marvin_panel_Container_172;
extern leWidget* Marvin_panel_Container_174;
extern leWidget* Marvin_panel_Container_176;
extern leWidget* Marvin_panel_Container_178;
extern leWidget* Marvin_panel_Container_180;
extern leWidget* Marvin_panel_Heading_3_4;
extern leWidget* Marvin_panel_Container_181;
extern leLabelWidget* Marvin_label_CONFIGURATION;
extern leWidget* Marvin_panel_Container_182;
extern leWidget* Marvin_panel_Container_186;
extern leWidget* Marvin_panel_Container__margin__11;
extern leWidget* Marvin_panel_Container_183;
extern leWidget* Marvin_panel_Text_21;
extern leWidget* Marvin_panel_Label;
extern leWidget* Marvin_panel_Text_20;
extern leLabelWidget* Marvin_label_RESPONSE_DELAY;
extern leLabelWidget* Marvin_label__45ms;
extern leWidget* Marvin_panel_Container_184;
extern leWidget* Marvin_panel_Container_185;
extern leWidget* Marvin_panel_Container_187;
extern leWidget* Marvin_panel_Text_23;
extern leWidget* Marvin_panel_Label_0;
extern leWidget* Marvin_panel_Text_22;
extern leLabelWidget* Marvin_label_SENSITIVITY;
extern leLabelWidget* Marvin_label__75_;
extern leWidget* Marvin_panel_Container_188;
extern leWidget* Marvin_panel_Container_189;
extern leWidget* Marvin_panel_Container_190;
extern leWidget* Marvin_panel_Container_191;
extern leWidget* Marvin_panel_Container_192;
extern leWidget* Marvin_panel_Container_193;
extern leWidget* Marvin_panel_Label_1;
extern leWidget* Marvin_panel_Switch;
extern leLabelWidget* Marvin_label_AUTO_CALIBRATE;
extern leWidget* Marvin_panel_Text_24;
extern leWidget* Marvin_panel_Label_2;
extern leWidget* Marvin_panel_Switch_0;
extern leLabelWidget* Marvin_label_DEBUG_MODE;
extern leWidget* Marvin_panel_Text_25;
extern leWidget* Marvin_panel_Label_3;
extern leWidget* Marvin_panel_Switch_1;
extern leLabelWidget* Marvin_label_AUTO_RECOVERY;
extern leWidget* Marvin_panel_Text_26;
extern leWidget* Marvin_PANEL_NAVIGATION;
extern leWidget* Marvin_PANEL_NAVIGATION_TOP;
extern leWidget* Marvin_PANEL_NAVIGATION_MIDDLE;
extern leWidget* Marvin_PANEL_NAVIGATION_BOTTOM;
extern leLabelWidget* Marvin_LABEL_NAVIGATION;
extern leLabelWidget* Marvin_LABEL_NAV_SUB_HEADING;
extern leButtonWidget* Marvin_BUTTON_NAV_DASHBOARD;
extern leButtonWidget* Marvin_BUTTON_NAV_LOGS;
extern leButtonWidget* Marvin_BUTTON_NAV_PERFORMANCE;
extern leButtonWidget* Marvin_BUTTON_NAV_SYSTEM_INFO;
extern leButtonWidget* Marvin_BUTTON_NAV_DIAGNOSTICS;
extern leButtonWidget* Marvin_BUTTON_NAV_SETTINGS;
extern leWidget* Marvin_panel_Container_196;
extern leWidget* Marvin_panel_Container_197;
extern leWidget* Marvin_panel_Container_198;
extern leWidget* Marvin_panel_Container_199;
extern leWidget* Marvin_panel_Container_200;
extern leLabelWidget* Marvin_label_STATUS;
extern leLabelWidget* Marvin_label_Connected;

// event handlers
// !!THESE MUST BE IMPLEMENTED IN THE APPLICATION CODE!!
void event_Marvin_BUTTON_SYSYEM_NAVIGATION_OnPressed(leButtonWidget* btn);
void event_Marvin_BUTTON_GUITAR_STRUM_UP_OnPressed(leButtonWidget* btn);
void event_Marvin_BUTTON_GUITAR_STRUM_UP_OnReleased(leButtonWidget* btn);
void event_Marvin_BUTTON_GUITAR_STRUM_DOWN_OnPressed(leButtonWidget* btn);
void event_Marvin_BUTTON_GUITAR_STRUM_DOWN_OnReleased(leButtonWidget* btn);
void event_Marvin_BUTTON_NAV_DASHBOARD_OnReleased(leButtonWidget* btn);

// screen lifecycle functions
// DO NOT CALL THESE DIRECTLY
leResult screenInit_Marvin(void); // called when Legato is initialized
leResult screenShow_Marvin(void); // called when screen is shown
void screenHide_Marvin(void); // called when screen is hidden
void screenDestroy_Marvin(void); // called when Legato is destroyed
void screenUpdate_Marvin(void); // called when Legato is updating

leWidget* screenGetRoot_Marvin(uint32_t lyrIdx); // gets a root widget for this screen

// Screen Events:
void Marvin_OnShow(void); // called when this screen is shown

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif // LE_GEN_SCREEN_MARVIN_H
