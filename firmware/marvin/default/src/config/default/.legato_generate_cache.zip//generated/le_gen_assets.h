/*******************************************************************************
 Module for Microchip Legato Graphics Library

  Company:
    Microchip Technology Inc.

  File Name:
    le_gen_assets.h

  Summary:
    Header file containing a list of asset specifications for use with the
    Legato Graphics Stack.


  Description:
    Header file containing a list of asset specifications for use with the
    Legato Graphics Stack.

*******************************************************************************/


// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C)  Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

// DOM-IGNORE-END

#ifndef LE_GEN_ASSETS_H
#define LE_GEN_ASSETS_H

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

#include "gfx/legato/legato.h"

extern const lePalette leGlobalPalette;

/*****************************************************************************
 * Legato Graphics Image Assets
 *****************************************************************************/
/*********************************
 * Legato Image Asset
 * Name:   Marvin
 * Size:   1280x800 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Marvin;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_4
 * Size:   16x16 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_4;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_5
 * Size:   16x16 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_5;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_8
 * Size:   14x14 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_8;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_9
 * Size:   14x14 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_9;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_10
 * Size:   14x14 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_10;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_0
 * Size:   16x16 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_0;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_1
 * Size:   16x16 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_1;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_2
 * Size:   20x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_2;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_3
 * Size:   16x16 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_3;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_6
 * Size:   20x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_6;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_7
 * Size:   20x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_7;

/*********************************
 * Legato Image Asset
 * Name:   BUTTON_ICON_HAMBURGER
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage BUTTON_ICON_HAMBURGER;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_12
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_12;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_13
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_13;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_14
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_14;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_15
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_15;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_16
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_16;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_11
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_11;

/*********************************
 * Legato Image Asset
 * Name:   WII_CTRL_LED_DISABLED
 * Size:   8x8 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage WII_CTRL_LED_DISABLED;

/*********************************
 * Legato Image Asset
 * Name:   WII_CTRL_LED_ENABLED
 * Size:   8x8 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage WII_CTRL_LED_ENABLED;

/*********************************
 * Legato Image Asset
 * Name:   STAND_BY
 * Size:   718x478 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage STAND_BY;

/*********************************
 * Legato Image Asset
 * Name:   VIDEO_LED_NO_SIGNAL
 * Size:   8x8 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage VIDEO_LED_NO_SIGNAL;

/*********************************
 * Legato Image Asset
 * Name:   LED_SYSTEM_ACTIVE
 * Size:   12x12 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage LED_SYSTEM_ACTIVE;

/*********************************
 * Legato Image Asset
 * Name:   LED_SYSTEM_INACTIVE
 * Size:   12x12 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage LED_SYSTEM_INACTIVE;

/*********************************
 * Legato Image Asset
 * Name:   BUTTON_ICON_CHECK
 * Size:   20x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage BUTTON_ICON_CHECK;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_17
 * Size:   20x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_17;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_0_0
 * Size:   14x14 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_0_0;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_1_0
 * Size:   14x14 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_1_0;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_18
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_18;

/*********************************
 * Legato Image Asset
 * Name:   LemmyOnStagePlayerImage
 * Size:   254x208 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage LemmyOnStagePlayerImage;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_0_1
 * Size:   20x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_0_1;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_1_1
 * Size:   20x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_1_1;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_2_0
 * Size:   20x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_2_0;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon_3_0
 * Size:   20x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon_3_0;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_TiltControl
 * Size:   157x157 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_TiltControl;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_TiltControl_0
 * Size:   157x157 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_TiltControl_0;

/*********************************
 * Legato Image Asset
 * Name:   figmaImg_Icon
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage figmaImg_Icon;

/*********************************
 * Legato Image Asset
 * Name:   LemmyOnStagePlayerImage_gradient
 * Size:   254x208 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage LemmyOnStagePlayerImage_gradient;

/*********************************
 * Legato Image Asset
 * Name:   HumanPlayer
 * Size:   254x208 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage HumanPlayer;

/*********************************
 * Legato Image Asset
 * Name:   HumanPlayer_gradient
 * Size:   254x208 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage HumanPlayer_gradient;

/*********************************
 * Legato Image Asset
 * Name:   Gemini_Generated_Image_9oeot89oeot89oeo
 * Size:   402x53 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Gemini_Generated_Image_9oeot89oeot89oeo;

/*********************************
 * Legato Image Asset
 * Name:   LOGO_PIC
 * Size:   121x43 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage LOGO_PIC;

/*********************************
 * Legato Image Asset
 * Name:   LOGO_GUITAR
 * Size:   225x45 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage LOGO_GUITAR;

/*********************************
 * Legato Image Asset
 * Name:   LOGO_MICROCHIP
 * Size:   194x45 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage LOGO_MICROCHIP;

/*********************************
 * Legato Image Asset
 * Name:   LOGO_MGS
 * Size:   162x45 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage LOGO_MGS;

/*********************************
 * Legato Image Asset
 * Name:   Image0
 * Size:   61x42 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage Image0;

/*****************************************************************************
 * Legato Graphics Font Assets
 *****************************************************************************/
/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMono_12
 * Height:       37
 * Baseline:     12
 * Style:        Antialias
 * Glyph Count:  194
 * Range Count:  20
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
                 0x2014
                 0x25A0
                 0x2605
***********************************/
extern leRasterFont DejaVuSansMono_12;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMono_14
 * Height:       37
 * Baseline:     14
 * Style:        Antialias
 * Glyph Count:  191
 * Range Count:  15
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
***********************************/
extern leRasterFont DejaVuSansMono_14;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMono_16
 * Height:       37
 * Baseline:     15
 * Style:        Antialias
 * Glyph Count:  191
 * Range Count:  15
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
***********************************/
extern leRasterFont DejaVuSansMono_16;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMono_18
 * Height:       37
 * Baseline:     17
 * Style:        Antialias
 * Glyph Count:  195
 * Range Count:  8
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
                 0x25B2
                 0x25B6
                 0x25BC
                 0x25C0
***********************************/
extern leRasterFont DejaVuSansMono_18;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMono_20
 * Height:       37
 * Baseline:     19
 * Style:        Antialias
 * Glyph Count:  191
 * Range Count:  7
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
***********************************/
extern leRasterFont DejaVuSansMono_20;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMono_24
 * Height:       37
 * Baseline:     22
 * Style:        Antialias
 * Glyph Count:  191
 * Range Count:  4
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
***********************************/
extern leRasterFont DejaVuSansMono_24;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMonoBold_18
 * Height:       37
 * Baseline:     17
 * Style:        Antialias
 * Glyph Count:  191
 * Range Count:  12
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
***********************************/
extern leRasterFont DejaVuSansMonoBold_18;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMonoBold_14
 * Height:       37
 * Baseline:     14
 * Style:        Antialias
 * Glyph Count:  191
 * Range Count:  12
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
***********************************/
extern leRasterFont DejaVuSansMonoBold_14;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMonoBold_24
 * Height:       37
 * Baseline:     22
 * Style:        Antialias
 * Glyph Count:  191
 * Range Count:  10
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
***********************************/
extern leRasterFont DejaVuSansMonoBold_24;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMonoBold_12
 * Height:       37
 * Baseline:     11
 * Style:        Antialias
 * Glyph Count:  192
 * Range Count:  10
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
                 0x2605
***********************************/
extern leRasterFont DejaVuSansMonoBold_12;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMonoBold_16
 * Height:       37
 * Baseline:     15
 * Style:        Antialias
 * Glyph Count:  191
 * Range Count:  6
 * Glyph Ranges: 0x20-0x7E
                 0xA0-0xFF
***********************************/
extern leRasterFont DejaVuSansMonoBold_16;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMonoBold_40
 * Height:       37
 * Baseline:     33
 * Style:        Antialias
 * Glyph Count:  97
 * Range Count:  3
 * Glyph Ranges: 0x20-0x7E
                 0x232B
                 0x2713
***********************************/
extern leRasterFont DejaVuSansMonoBold_40;

/*********************************
 * Legato Font Asset
 * Name:         DejaVuSansMono_9
 * Height:       37
 * Baseline:     8
 * Style:        Antialias
 * Glyph Count:  95
 * Range Count:  1
 * Glyph Ranges: 0x20-0x7E
***********************************/
extern leRasterFont DejaVuSansMono_9;

/*****************************************************************************
 * Legato String Table
 * Encoding        UTF8
 * Language Count: 1
 * String Count:   102
 *****************************************************************************/

// language IDs
#define language_Default    0

// string IDs
#define stringID_PLAYER_ROBOT_DETECTOR    0
#define stringID_WIIMOTES_ENABLED    1
#define stringID_PLAYER_MULTIPLIER_1x    2
#define stringID_PLAYER_STREAK    3
#define stringID_SONG_SELECT_EASY    4
#define stringID_SONG_INFO_Status    5
#define stringID_WIIMOTE_HEADING    6
#define stringID_SONG_SELECT_YEAR    7
#define stringID_WIIMOTE_A    8
#define stringID_NAV_BUTTON_System_Info    9
#define stringID_SONG_SELECT_SongYear    10
#define stringID_SONG_INFO_Tier    11
#define stringID_GUITAR_PLUS    12
#define stringID_NAV_ConnectionStatus    13
#define stringID_NAV_BUTTON_Activity_Logs    14
#define stringID_SONG_INFO_STOP_TIME    15
#define stringID_SONG_SELECT_SongTier    16
#define stringID_SONG_SELECT_SELECT    17
#define stringID_SONG_INFO_TIER    18
#define stringID_SONG_INFO_START_TIME    19
#define stringID_PLAYER_HUMAN_Battery    20
#define stringID_WIIMOTE_DPAD_UP    21
#define stringID_SONG_SELECT_SELECT_SONG    22
#define stringID_SONG_SELECT_EXPERT    23
#define stringID_SONG_SELECT_1P_HUMAN    24
#define stringID_PLAYER_SCORE    25
#define stringID_WIIMOTE_B    26
#define stringID_SONG_INFO_Album_Year    27
#define stringID_SONG_INFO_Artist    28
#define stringID_SONG_SELECT_DIFFICULTY    29
#define stringID_NAV_BUTTON_Settings    30
#define stringID_WIIMOTE_DPAD_LEFT    31
#define stringID_PLAYER_STAR_POWER    32
#define stringID_PLAYER_HUMAN_Wii_remote    33
#define stringID_GUITAR_MINUS    34
#define stringID_SONG_INFO_Genre    35
#define stringID_PLAYER_HUMAN_RemoteStatus    36
#define stringID_PLAYER_Streak    37
#define stringID_PLAYER_StarPower    38
#define stringID_SONG_SELECT_1P_ROBOT    39
#define stringID_WIIMOTE_DPAD_DOWN    40
#define stringID_SONG_INFO_GENRE    41
#define stringID_NAV_Marvin_v1_0_0    42
#define stringID_PLAYER_Accuracy    43
#define stringID_GAMEPLAY_SELECT_SONG    44
#define stringID_SONG_SELECT_SongTitle    45
#define stringID_NAV_BUTTON_Dashboard    46
#define stringID_SONG_GAMEPLAY_DIFFICULTY    47
#define stringID_SONG_SELECT_2P_ROBOT_vs_HUMAN    48
#define stringID_SONG_SELECT_MEDIUM    49
#define stringID_WIIMOTE_ONE    50
#define stringID_SONG_INFO_DURATION    51
#define stringID_PLAYER_ROBOT_GUITAR_ACTUATORS    52
#define stringID_GAMEPLAY_MODE_1P_ROBOT    53
#define stringID_PLAYER_MULTIPLIER_2x    54
#define stringID_SONG_SELECT_SongArtist    55
#define stringID_PLAYER_HUMAN_HumanPlayer    56
#define stringID_PLAYER_HUMAN_Name    57
#define stringID_SONG_SELECT_ALBUM    58
#define stringID_SONG_SELECT_DURATION    59
#define stringID_GUITAR_STRUM_UP    60
#define stringID_SONG_SELECT_SongDuration    61
#define stringID_GUITAR_EXTENSION    62
#define stringID_PLAYER_STRUM_BAR    63
#define stringID_GUITAR_WHAMMY    64
#define stringID_VIDEO_NO_SIGNAL    65
#define stringID_GUITAR_STRUM_DOWN    66
#define stringID_WIIMOTE_HOME    67
#define stringID_SONG_SELECT_SongGenre    68
#define stringID_PLAYER_HUMAN_CONTROLLER    69
#define stringID_SONG_SELECT_SongAlbum    70
#define stringID_NAV_BUTTON_Performance    71
#define stringID_NAV_BUTTON_Diagnostics    72
#define stringID_PLAYER_ROBOT_RobotPlayer    73
#define stringID_WIIMOTE_TWO    74
#define stringID_PLAYER_ROBOT_Score    75
#define stringID_NAV_BUTTON_Wiimotes    76
#define stringID_PLAYER_ROBOT_Computer_Vision    77
#define stringID_PLAYER_HUMAN_GuitarStatus    78
#define stringID_WIIMOTE_TILT    79
#define stringID_PLAYER_ROBOT_Status    80
#define stringID_WIIMOTE_DPAD_RIGHT    81
#define stringID_SONG_GAMEPLAY_MODE    82
#define stringID_SONG_INFO_Duration    83
#define stringID_PLAYER_HUMAN_Wii_guitar    84
#define stringID_PLAYER_ROBOT_FRET_ACTIVITY    85
#define stringID_SONG_SELECT_HARD    86
#define stringID_SONG_SELECT_MODE    87
#define stringID_PLAYER_ROBOT_Neural_Network    88
#define stringID_SONG_SELECT_GENRE    89
#define stringID_PLAYER_HUMAN_BatteryLevel    90
#define stringID_SONG_SELECT_SETLIST    91
#define stringID_SONG_GAMEPLAY_EASY    92
#define stringID_PLAYER_ROBOT_Name    93
#define stringID_PLAYER_MULTIPLIER_4x    94
#define stringID_SONG_INFO_Title    95
#define stringID_NAV_NAVIGATION    96
#define stringID_PLAYER_STRUM_BAR_Status    97
#define stringID_GAMEPLAY_START    98
#define stringID_PLAYER_ACCURACY    99
#define stringID_PLAYER_MULTIPLIER_3x    100
#define stringID_NAV_STATUS    101

extern const leStringTable stringTable;


// string list
extern leTableString string_PLAYER_ROBOT_DETECTOR;
extern leTableString string_WIIMOTES_ENABLED;
extern leTableString string_PLAYER_MULTIPLIER_1x;
extern leTableString string_PLAYER_STREAK;
extern leTableString string_SONG_SELECT_EASY;
extern leTableString string_SONG_INFO_Status;
extern leTableString string_WIIMOTE_HEADING;
extern leTableString string_SONG_SELECT_YEAR;
extern leTableString string_WIIMOTE_A;
extern leTableString string_NAV_BUTTON_System_Info;
extern leTableString string_SONG_SELECT_SongYear;
extern leTableString string_SONG_INFO_Tier;
extern leTableString string_GUITAR_PLUS;
extern leTableString string_NAV_ConnectionStatus;
extern leTableString string_NAV_BUTTON_Activity_Logs;
extern leTableString string_SONG_INFO_STOP_TIME;
extern leTableString string_SONG_SELECT_SongTier;
extern leTableString string_SONG_SELECT_SELECT;
extern leTableString string_SONG_INFO_TIER;
extern leTableString string_SONG_INFO_START_TIME;
extern leTableString string_PLAYER_HUMAN_Battery;
extern leTableString string_WIIMOTE_DPAD_UP;
extern leTableString string_SONG_SELECT_SELECT_SONG;
extern leTableString string_SONG_SELECT_EXPERT;
extern leTableString string_SONG_SELECT_1P_HUMAN;
extern leTableString string_PLAYER_SCORE;
extern leTableString string_WIIMOTE_B;
extern leTableString string_SONG_INFO_Album_Year;
extern leTableString string_SONG_INFO_Artist;
extern leTableString string_SONG_SELECT_DIFFICULTY;
extern leTableString string_NAV_BUTTON_Settings;
extern leTableString string_WIIMOTE_DPAD_LEFT;
extern leTableString string_PLAYER_STAR_POWER;
extern leTableString string_PLAYER_HUMAN_Wii_remote;
extern leTableString string_GUITAR_MINUS;
extern leTableString string_SONG_INFO_Genre;
extern leTableString string_PLAYER_HUMAN_RemoteStatus;
extern leTableString string_PLAYER_Streak;
extern leTableString string_PLAYER_StarPower;
extern leTableString string_SONG_SELECT_1P_ROBOT;
extern leTableString string_WIIMOTE_DPAD_DOWN;
extern leTableString string_SONG_INFO_GENRE;
extern leTableString string_NAV_Marvin_v1_0_0;
extern leTableString string_PLAYER_Accuracy;
extern leTableString string_GAMEPLAY_SELECT_SONG;
extern leTableString string_SONG_SELECT_SongTitle;
extern leTableString string_NAV_BUTTON_Dashboard;
extern leTableString string_SONG_GAMEPLAY_DIFFICULTY;
extern leTableString string_SONG_SELECT_2P_ROBOT_vs_HUMAN;
extern leTableString string_SONG_SELECT_MEDIUM;
extern leTableString string_WIIMOTE_ONE;
extern leTableString string_SONG_INFO_DURATION;
extern leTableString string_PLAYER_ROBOT_GUITAR_ACTUATORS;
extern leTableString string_GAMEPLAY_MODE_1P_ROBOT;
extern leTableString string_PLAYER_MULTIPLIER_2x;
extern leTableString string_SONG_SELECT_SongArtist;
extern leTableString string_PLAYER_HUMAN_HumanPlayer;
extern leTableString string_PLAYER_HUMAN_Name;
extern leTableString string_SONG_SELECT_ALBUM;
extern leTableString string_SONG_SELECT_DURATION;
extern leTableString string_GUITAR_STRUM_UP;
extern leTableString string_SONG_SELECT_SongDuration;
extern leTableString string_GUITAR_EXTENSION;
extern leTableString string_PLAYER_STRUM_BAR;
extern leTableString string_GUITAR_WHAMMY;
extern leTableString string_VIDEO_NO_SIGNAL;
extern leTableString string_GUITAR_STRUM_DOWN;
extern leTableString string_WIIMOTE_HOME;
extern leTableString string_SONG_SELECT_SongGenre;
extern leTableString string_PLAYER_HUMAN_CONTROLLER;
extern leTableString string_SONG_SELECT_SongAlbum;
extern leTableString string_NAV_BUTTON_Performance;
extern leTableString string_NAV_BUTTON_Diagnostics;
extern leTableString string_PLAYER_ROBOT_RobotPlayer;
extern leTableString string_WIIMOTE_TWO;
extern leTableString string_PLAYER_ROBOT_Score;
extern leTableString string_NAV_BUTTON_Wiimotes;
extern leTableString string_PLAYER_ROBOT_Computer_Vision;
extern leTableString string_PLAYER_HUMAN_GuitarStatus;
extern leTableString string_WIIMOTE_TILT;
extern leTableString string_PLAYER_ROBOT_Status;
extern leTableString string_WIIMOTE_DPAD_RIGHT;
extern leTableString string_SONG_GAMEPLAY_MODE;
extern leTableString string_SONG_INFO_Duration;
extern leTableString string_PLAYER_HUMAN_Wii_guitar;
extern leTableString string_PLAYER_ROBOT_FRET_ACTIVITY;
extern leTableString string_SONG_SELECT_HARD;
extern leTableString string_SONG_SELECT_MODE;
extern leTableString string_PLAYER_ROBOT_Neural_Network;
extern leTableString string_SONG_SELECT_GENRE;
extern leTableString string_PLAYER_HUMAN_BatteryLevel;
extern leTableString string_SONG_SELECT_SETLIST;
extern leTableString string_SONG_GAMEPLAY_EASY;
extern leTableString string_PLAYER_ROBOT_Name;
extern leTableString string_PLAYER_MULTIPLIER_4x;
extern leTableString string_SONG_INFO_Title;
extern leTableString string_NAV_NAVIGATION;
extern leTableString string_PLAYER_STRUM_BAR_Status;
extern leTableString string_GAMEPLAY_START;
extern leTableString string_PLAYER_ACCURACY;
extern leTableString string_PLAYER_MULTIPLIER_3x;
extern leTableString string_NAV_STATUS;

void initializeStrings(void);
//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif /* LE_GEN_ASSETS_H */
